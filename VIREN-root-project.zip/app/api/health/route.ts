import {NextResponse} from 'next/server'; import {db} from '@/lib/db';
export async function GET(){try{const {error}=await db().from('servers').select('id').limit(1); if(error)throw error; return NextResponse.json({ok:true,timezone:process.env.DEFAULT_TIMEZONE||'Asia/Manila'});}catch{return NextResponse.json({ok:false,error:'Database unavailable'},{status:503})}}
