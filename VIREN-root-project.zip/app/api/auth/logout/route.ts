import {NextResponse} from 'next/server'; import {clearSession,getSession} from '@/lib/auth'; import {db} from '@/lib/db';
export async function POST(){const s=await getSession(); if(s)await db().from('audit_logs').insert({actor_id:s.id,action:'LOGOUT',target_type:'account',target_id:s.id,details:{}}); await clearSession(); return NextResponse.json({ok:true});}
