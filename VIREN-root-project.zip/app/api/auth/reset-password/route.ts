import {NextRequest,NextResponse} from 'next/server';
import {db} from '@/lib/db';
import {hashPassword} from '@/lib/security';
import crypto from 'node:crypto';

export async function POST(req:NextRequest){
  try {
    const {token,password}=await req.json();
    if(typeof token!=='string'||typeof password!=='string'||password.length<8)
      return NextResponse.json({error:'Invalid reset request'},{status:400});
    const tokenHash=crypto.createHash('sha256').update(token).digest('hex');
    const d=db();
    const consumed=await d.rpc('consume_recovery_token',{p_token_hash:tokenHash});
    if(consumed.error||!consumed.data)
      return NextResponse.json({error:'Reset link is invalid or expired'},{status:400});
    const accountId=consumed.data as string;
    const up=await d.from('accounts').update({password_hash:hashPassword(password)}).eq('id',accountId).eq('status','active');
    if(up.error||!up.count) return NextResponse.json({error:'Unable to change password'},{status:500});
    await d.from('sessions').update({revoked_at:new Date().toISOString()}).eq('account_id',accountId).is('revoked_at',null);
    await d.from('audit_logs').insert({actor_id:accountId,action:'PASSWORD_RESET',target_type:'account',target_id:accountId,details:{}});
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:'Unable to reset password'},{status:500});
  }
}
