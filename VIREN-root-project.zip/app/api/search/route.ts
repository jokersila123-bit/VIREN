import {NextResponse} from 'next/server';
import {db} from '@/lib/db';

export async function GET(req:Request){
 const q=new URL(req.url).searchParams.get('q')?.trim()||'';
 if(q.length<2)return NextResponse.json({results:[]});
 const term=`%${q.replace(/[%_]/g,'\\$&')}%`; const d=db();
 const [a,s,e,n]=await Promise.all([
  d.from('accounts').select('id,display_name,ign,username,level').eq('status','active').or(`display_name.ilike.${term},ign.ilike.${term},username.ilike.${term}`).limit(20),
  d.from('servers').select('id,name,slug,description').eq('active',true).or(`name.ilike.${term},slug.ilike.${term}`).limit(10),
  d.from('events').select('id,title,starts_at,status,server:servers(name)').in('status',['published','open']).ilike('title',term).limit(10),
  d.from('announcements').select('id,title,published_at,server:servers(name)').not('published_at','is',null).is('archived_at',null).ilike('title',term).limit(10)
 ]);
 return NextResponse.json({results:[...(a.data||[]).map(x=>({type:'member',...x})),...(s.data||[]).map(x=>({type:'server',...x})),...(e.data||[]).map(x=>({type:'event',...x})),...(n.data||[]).map(x=>({type:'announcement',...x}))]});
}
