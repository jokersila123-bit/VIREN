import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { getSession } from '@/lib/auth';
import { db } from '@/lib/db';

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const action = String(body.action || '');
    const target = body.target_id ? String(body.target_id) : null;
    const amount = body.amount == null ? null : Number(body.amount);
    const key = String(body.idempotency_key || crypto.randomUUID());

    if (!['work', 'daily', 'rob', 'transfer', 'coinflip', 'dice', 'slots'].includes(action)) {
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }

    const { data, error } = await db().rpc('economy_action_atomic', {
      p_account: session.id,
      p_action: action,
      p_amount: Number.isFinite(amount) ? amount : null,
      p_target: target,
      p_key: key,
    });

    if (error) {
      const message = error.message || 'Economy action failed';
      const status = ['COOLDOWN', 'INVALID_TARGET', 'TARGET_NOT_FOUND', 'NO_COINS', 'INVALID_TRANSFER', 'INVALID_BET', 'INSUFFICIENT_OR_MISSING_BALANCE'].includes(message) ? 409 : 400;
      return NextResponse.json({ error: message }, { status });
    }

    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: 'Invalid economy request' }, { status: 400 });
  }
}
