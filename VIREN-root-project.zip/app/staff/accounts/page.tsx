'use client';
import {useEffect,useState} from 'react';
export default function Accounts(){
  const [rows,setRows]=useState<any[]>([]); const [err,setErr]=useState(''); const [isDev,setIsDev]=useState(false);
  async function load(){const [r,m]=await Promise.all([fetch('/api/staff/accounts'),fetch('/api/auth/me')]);const j=await r.json();const mj=await m.json();setIsDev(mj?.session?.global_role==='dev');if(!r.ok){setErr(j.error||'Forbidden');return}setRows(j.accounts||[])}
  useEffect(()=>{load()},[]);
  async function update(id:string,patch:any){const r=await fetch('/api/staff/accounts',{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({id,...patch})});if(!r.ok){const j=await r.json().catch(()=>({}));setErr(j.error||'Update failed')}load()}
  return <main className="page"><p className="eyebrow">STAFF</p><h1>ACCOUNTS</h1>{err&&<div className="panel notice">{err}</div>}<div className="table-wrap"><table><thead><tr><th>USERNAME</th><th>ROLE</th><th>STATUS</th><th>LEVEL</th><th>COINS</th><th>ACTION</th></tr></thead><tbody>{rows.map(x=><tr key={x.id}><td>{x.username}</td><td>{isDev?<select value={x.global_role} onChange={e=>update(x.id,{global_role:e.target.value})}><option value="member">member</option><option value="officer">officer</option><option value="moderator">moderator</option><option value="dev">dev</option></select>:x.global_role}</td><td>{x.status}</td><td>{x.level}</td><td>{x.coin_balance}</td><td><select value={x.status} onChange={e=>update(x.id,{status:e.target.value})}><option>active</option><option>suspended</option><option>archived</option><option>terminated</option></select></td></tr>)}</tbody></table></div></main>
}
