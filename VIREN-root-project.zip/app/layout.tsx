import './globals.css'; import Nav from '@/components/nav';
export const metadata={title:'VIREN VRN | One Clan. One Legacy. One Dynasty.',description:'The official VIREN VRN community platform.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Nav/><div className="shell">{children}</div><footer><div><b>VIREN VRN</b><span>ONE CLAN · ONE LEGACY · ONE DYNASTY</span></div><small>© {new Date().getFullYear()} VIREN. All rights reserved.</small></footer></body></html>}
