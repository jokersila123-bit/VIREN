interface CloudflareEnv {
  DB: D1Database;
  MEDIA: R2Bucket;
  SESSION_SECRET: string;
  NEXT_PUBLIC_SITE_URL?: string;
}
