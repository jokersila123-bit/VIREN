# VIREN — Cloudflare deployment

The production architecture is Cloudflare-native:

- Next.js 16 + OpenNext on Cloudflare Workers
- Cloudflare D1 for application data
- Cloudflare R2 for private media
- HttpOnly signed session cookie for authentication
- No Supabase dependency

## 1. Create resources

```bash
npx wrangler login
npx wrangler d1 create viren-vrn-staging-db --location apac
npx wrangler d1 create viren-vrn-db --location apac
npx wrangler r2 bucket create viren-media-staging
npx wrangler r2 bucket create viren-media
```

Put the returned D1 database IDs into `wrangler.jsonc` for staging and production.

## 2. Initialize D1

```bash
npx wrangler d1 execute viren-vrn-staging-db --remote --file=sql/schema.sql
npx wrangler d1 execute viren-vrn-db --remote --file=sql/schema.sql
```

For a local Workers preview:

```bash
npx wrangler d1 execute viren-vrn-staging-db --local --file=sql/schema.sql
```

## 3. Secrets

Set `SESSION_SECRET` as a Cloudflare secret. It must be at least 32 random characters in production.

Set `NEXT_PUBLIC_SITE_URL` as an environment variable for the deployment.

Do not put Cloudflare API tokens, database credentials, or secrets in the repository.

## 4. Build and preview

```bash
npm install
npm run verify
npm run preview
```

The Workers preview is the production-like verification path.

## 5. Deploy

```bash
npm run deploy -- --env staging
npm run deploy -- --env production
```

Cloudflare's current guidance supports D1 bindings directly in Workers and OpenNext access through `getCloudflareContext`. The project is configured around those bindings.
