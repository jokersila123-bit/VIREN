# VIREN production deployment

## Architecture

Browser → Cloudflare Worker/OpenNext → D1 + R2

## Required Cloudflare resources

- Worker: `viren-vrn-staging` and `viren-vrn`
- D1: `viren-vrn-staging-db` and `viren-vrn-db`
- R2: `viren-media-staging` and `viren-media`

## Required configuration

`wrangler.jsonc` must contain the real D1 IDs before deployment.

Secrets:

- `SESSION_SECRET`

Environment variables:

- `NEXT_PUBLIC_SITE_URL`

## Deployment order

1. Create staging D1 and R2.
2. Apply `sql/schema.sql` to staging.
3. Set staging secret/environment values.
4. Run `npm run verify`.
5. Run `npm run preview`.
6. Execute the end-to-end acceptance tests.
7. Create production D1 and R2.
8. Apply the same schema to production.
9. Set production secret/environment values.
10. Deploy production.
11. Verify authentication, memberships, lineup, attendance, events, announcements, economy, media and admin permissions.
12. Lock the release.

No claim of production readiness should be made until the actual Cloudflare deployment and end-to-end tests have been executed.
