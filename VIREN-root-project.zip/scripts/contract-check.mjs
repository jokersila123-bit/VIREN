import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const requiredFiles = [
  'sql/schema.sql',
  'app/api/auth/login/route.ts',
  'app/api/auth/logout/route.ts',
  'app/api/auth/recovery/route.ts',
  'app/api/auth/reset-password/route.ts',
  'app/api/recruitment/route.ts',
  'app/api/staff/applications/[id]/approve/route.ts',
  'app/api/staff/memberships/route.ts',
  'app/api/staff/attendance/route.ts',
  'app/api/events/[id]/register/route.ts',
  'app/api/events/[id]/cancel/route.ts',
  'app/api/economy/actions/route.ts',
  'app/api/store/route.ts',
  'app/api/media/route.ts',
  'app/api/reports/route.ts',
  'app/api/notifications/route.ts',
  'app/api/admin/settings/route.ts',
];
const requiredPages = [
  'app/page.tsx','app/about/page.tsx','app/servers/page.tsx','app/roster/page.tsx',
  'app/events/page.tsx','app/recruitment/page.tsx','app/login/page.tsx','app/attendance/page.tsx',
  'app/portal/page.tsx','app/profile/page.tsx','app/vrn-coins/page.tsx','app/store/page.tsx',
  'app/reports/page.tsx','app/notifications/page.tsx','app/gallery/page.tsx',
  'app/staff/page.tsx','app/staff/accounts/page.tsx','app/staff/attendance/page.tsx',
  'app/staff/lineup/page.tsx','app/staff/reports/page.tsx','app/admin/settings/page.tsx'
];
const failures=[];
for (const f of [...requiredFiles,...requiredPages]) if (!fs.existsSync(path.join(root,f))) failures.push(`Missing required file: ${f}`);
const schema=fs.readFileSync(path.join(root,'sql/schema.sql'),'utf8');
const requiredSchema=[
  'CREATE TABLE IF NOT EXISTS accounts','CREATE TABLE IF NOT EXISTS server_memberships','CREATE TABLE IF NOT EXISTS applications',
  'CREATE TABLE IF NOT EXISTS attendance','CREATE TABLE IF NOT EXISTS events','CREATE TABLE IF NOT EXISTS event_registrations',
  'CREATE TABLE IF NOT EXISTS announcements','CREATE TABLE IF NOT EXISTS notifications','CREATE TABLE IF NOT EXISTS coin_transactions',
  'CREATE TABLE IF NOT EXISTS reports','CREATE TABLE IF NOT EXISTS audit_logs','CREATE TABLE IF NOT EXISTS sessions',
  'CREATE TABLE IF NOT EXISTS recovery_tokens','CREATE TABLE IF NOT EXISTS store_items','CREATE TABLE IF NOT EXISTS store_claims',
  'CREATE TABLE IF NOT EXISTS economy_cooldowns'
];
for (const marker of requiredSchema) if (!schema.toLowerCase().includes(marker.toLowerCase())) failures.push(`Missing schema contract: ${marker}`);
if (!schema.includes('UNIQUE(account_id,server_id)')) failures.push('Missing one-account/one-membership-per-server constraint');
if (!schema.includes('UNIQUE(event_id,account_id)')) failures.push('Missing one-registration-per-event constraint');
if (!schema.includes('idempotency_key TEXT UNIQUE')) failures.push('Missing economy/store idempotency constraint');
const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');
for (const key of ['SESSION_SECRET','NEXT_PUBLIC_SITE_URL']) if (!env.includes(key+'=')) failures.push(`Missing env contract: ${key}`);
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if (!pkg.scripts?.verify) failures.push('Missing npm verify script');
if (!pkg.engines?.node || !pkg.engines.node.includes('22')) failures.push('Node 22 engine requirement missing');
if (failures.length) { console.error('VIREN contract check: FAIL'); failures.forEach(x=>console.error(' - '+x)); process.exit(1); }
console.log('VIREN contract check: PASS');
console.log(`Checked ${requiredFiles.length} required API files, ${requiredPages.length} required pages, and ${requiredSchema.length} schema contracts.`);
