# VIREN staging runbook — Cloudflare

1. `npx wrangler login`
2. Create the staging D1 database.
3. Create the staging R2 bucket.
4. Put the real staging D1 ID in `wrangler.jsonc`.
5. Run `npx wrangler d1 execute viren-vrn-staging-db --remote --file=sql/schema.sql`.
6. Set `SESSION_SECRET` and `NEXT_PUBLIC_SITE_URL`.
7. Run `npm install`.
8. Run `npm run verify`.
9. Run `npm run preview`.
10. Test login/session persistence/logout.
11. Test recruitment → acceptance → memberships → roster.
12. Test server-scoped lineup permissions.
13. Test attendance review.
14. Test events and cancellation/withdrawal.
15. Test announcements, notifications and reports.
16. Test economy idempotency and store claims.
17. Test media upload/delete.
18. Test suspension/termination and audit preservation.
19. Deploy staging with `npm run deploy -- --env staging`.
20. Repeat the full acceptance suite against the deployed staging Worker.
