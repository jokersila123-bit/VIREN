# VIREN VRN

Production-oriented VIREN clan/community platform.

## Stack

- Next.js 16
- React 19
- Cloudflare Workers + OpenNext
- Cloudflare D1
- Cloudflare R2
- Server-side authentication and authorization
- HttpOnly signed sessions

## Core systems

Authentication, account lifecycle, multi-server memberships, server-scoped roles, recruitment, roster, lineup, attendance, events, announcements, notifications, reports, VRN Coins, store, presence, media, audit logs, settings and maintenance controls.

## Cloudflare setup

See `CLOUDFLARE.md` and `STAGING_RUNBOOK.md`.

This repository intentionally contains no Supabase dependency or Supabase credentials.
