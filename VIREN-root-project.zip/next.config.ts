import type { NextConfig } from 'next';
import { initOpenNextCloudflareForDev } from '@opennextjs/cloudflare';
initOpenNextCloudflareForDev();
const nextConfig: NextConfig = { reactStrictMode:true, poweredByHeader:false, compress:true, images:{remotePatterns:[]} };
export default nextConfig;
