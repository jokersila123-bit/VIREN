import crypto from 'node:crypto';
import { getCloudflareContext } from '@opennextjs/cloudflare';
const secret=()=>{try{const s=(getCloudflareContext().env as any).SESSION_SECRET;if(s)return s;}catch{} const s=process.env.SESSION_SECRET;if(!s&&process.env.NODE_ENV==='production')throw new Error('SESSION_SECRET is required in production');return s||'development-only-change-me';};
export function hashPassword(password:string){const salt=crypto.randomBytes(16).toString('hex');const hash=crypto.scryptSync(password,salt,64).toString('hex');return `scrypt$${salt}$${hash}`;}
export function verifyPassword(password:string,stored:string){try{const [algo,salt,hash]=stored.split('$');if(algo!=='scrypt'||!salt||!hash)return false;const candidate=crypto.scryptSync(password,salt,64).toString('hex');const a=Buffer.from(candidate,'hex'),b=Buffer.from(hash,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b)}catch{return false}}
export function sign(value:string){return crypto.createHmac('sha256',secret()).update(value).digest('hex')}
export function token(payload:object){const body=Buffer.from(JSON.stringify(payload)).toString('base64url');return `${body}.${sign(body)}`}
export function verifyToken<T=any>(raw:string){try{const [body,sig]=raw.split('.');if(!body||!sig)return null;const expected=sign(body),a=Buffer.from(sig),b=Buffer.from(expected);if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;return JSON.parse(Buffer.from(body,'base64url').toString()) as T}catch{return null}}
export function randomToken(){return crypto.randomBytes(32).toString('hex')}
