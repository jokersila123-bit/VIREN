export type Role='member'|'officer'|'moderator'|'dev';
export const roleRank:Record<Role,number>={member:10,officer:20,moderator:30,dev:40};
export function canGlobal(role:string,minimum:Role){return (roleRank[role as Role]||0)>=roleRank[minimum]}
export const serverRoles=['CM','VCM','ACM','ADM','HHC','HC','HEX','EX','HR','REC','MUSE','ESC','CF','GFX'] as const;
