import {db} from './db';

export async function canManageServer(session:any, serverId:string){
  if(!session) return false;
  if(['moderator','dev'].includes(session.global_role)) return true;
  if(session.global_role!=='officer') return false;
  const {data}=await db().from('server_memberships').select('id,server_role').eq('account_id',session.id).eq('server_id',serverId).eq('status','active').not('server_role','is',null).maybeSingle();
  return !!data;
}
